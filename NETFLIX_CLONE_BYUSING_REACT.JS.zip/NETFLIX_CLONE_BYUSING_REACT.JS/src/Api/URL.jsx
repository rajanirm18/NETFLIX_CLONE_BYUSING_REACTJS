export const WatchUrl=[

    "https://youtu.be/Kq21P71qPLc?si=3uen7ForJZdGDlUf",
    "https://youtu.be/pdCkt04x5ZU?si=yp-dAckzFs5480tp",
    "https://youtu.be/VlcI2Vu5uV4?si=9oz-AdvKjyP-Y3h6",
    "https://youtu.be/dqveKB-cZQM?si=jtQ0NrGuV5pwkXQP",
    "https://youtu.be/z3SWGP3N7Wo?si=pZM-26Fac_zfbESB",
    "https://youtu.be/AOJ-a6cx3bw?si=-Flgj7bcYfheQXNA",
    "https://youtu.be/SLtYpKf7XgM?si=iukjdh9Vg3gVRNe-",
    "https://youtu.be/0GfbyDMmwyE?si=GNUIXExlrrRm4aYD",
    "https://youtu.be/m2HVpBFUxjU?si=KmgInufF6iNCzzjc",
    "https://youtu.be/qOmPlxFUqMg?si=ByiayFwusTo6eyCP",
    "https://youtu.be/yPV124khbZ4?si=XwI8uYWNhay9J_m-",
    "https://youtu.be/ZQ_SjvoIR4k?si=ySYNrKjpiBAF6pJa",
    "https://youtu.be/1lz0ih9VCXQ?si=wBpW4iBI_Ah5R4wN",
    "https://youtu.be/T-tNMAYhyio?si=M3hE_aDxbOmT2OLr",
    "https://youtu.be/hoHzYtoJlz0?si=jJQuOr4Vwi9SOW_o",
    "https://youtu.be/z823XGhF8lE?si=Lr-Uvbpa_PAjkXbD",
    "https://youtu.be/IvcSZumt7cc?si=P2GW3wJhFgjvETZJ",
    "https://youtu.be/-Jts8lNYLJo?si=nNVdczRHfC25zjOx",
    "https://youtu.be/CJq1Vci8gtc?si=gQdWqop5aHP_Ztag",
    "https://youtu.be/9LA5exrXOs8?si=PvDG-RqF6DhLNxtc"

]