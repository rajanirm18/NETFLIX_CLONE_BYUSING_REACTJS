import axios from 'axios';

const api= axios. create({
baseURL:'https://api.themoviedb.org/3',
params:{
    api_key:"1149579a0abb627b8878c44bfa5a0db9"
       }

})

export const getdata=()=>{
    
    return api.get("discover/movie")
}