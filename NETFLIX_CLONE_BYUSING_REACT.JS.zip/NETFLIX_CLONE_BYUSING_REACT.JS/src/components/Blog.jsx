import React from "react";
import { useEffect, useState } from "react";          // optional CSS file for styling

export const Blog = () => {

const [imageUrl, setImageUrl] = useState("");

  useEffect(() => {
    fetch("https://api.unsplash.com/photos/random?client_id=YOUR_ACCESS_KEY")
      .then(res => res.json())
      .then(data => setImageUrl(data.urls.small));
  }, []);

  
  const cards = [
    {
      id: 1,
      title: "Top 10 Trending Shows on Netflix",
      description: "A quick look at the most popular shows streaming right now.",
      img: "https://share.google/images/XneVSiY06X49uIlNf", // placeholder image
      link: "#"
    },
    {
      id: 2,
      title: "Upcoming Netflix Releases",
      description: "Strong lineup of new movies and shows coming this month.",
      img: "https://via.placeholder.com/350x200?text=Upcoming+Release",
      link: "#"
    },
    {
      id: 3,
      title: "Hidden Gems You Should Watch",
      description: "Underrated movies and series you may have missed.",
      img: "https://via.placeholder.com/350x200?text=Hidden+Gems",
      link: "#"
    },
  ];

  return (
  

    <div className="container">
      {cards.map((card) => (
        <div key={card.id} className="card">
          <img src={card.img} alt={card.title} className="card-image" />
          <div className="card-content">
            <h2>{card.title}</h2>
            <p>{card.description}</p>
            <button className="read-more">Read More</button>
          </div>
        </div>
      ))}
    </div>
    
  );
};