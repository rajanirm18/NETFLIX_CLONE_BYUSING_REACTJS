import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import {Home} from './components/Home.jsx'
import {Contact} from './components/Contact.jsx'
import {Blog} from'./components/Blog.jsx'
import './App.css'
import {Applayout} from './Applayout/Applayout.jsx'

function App() {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <Applayout />,
      children: [
        {
          path: "",
          element: <Home />
        },
        {
          path: "contact",
          element: <Contact />
        },
        {
          path: "blog",
          element: <Blog />
        }
      ]
    }
  ])

  return <RouterProvider router={router} />
}

export default App
