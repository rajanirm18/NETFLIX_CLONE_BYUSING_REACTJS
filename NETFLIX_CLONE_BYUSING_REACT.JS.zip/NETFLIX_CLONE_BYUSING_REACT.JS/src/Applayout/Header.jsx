import React from 'react'
import { NavLink } from 'react-router-dom';
export const Header = () => {
  return (
    <header className="bg-dark sticky-top py-2">
        <div className="container d-flex justify-content-between align-items-center">
            {/* Logo */}
        <div>
    <span style={{color:"#e50914", fontSize:"1.5rem", fontWeight:"700"}}>
        NETFLIX
        </span>
        </div>
            {/* Navigation Links */}
        <nav className="d-none d-md-flex">
    <NavLink to="/" className="text-white me-3 text-decoration-none fw-medium">Home</NavLink>
    <NavLink to="/contact" className="text-white me-3 text-decoration-none fw-medium">Contact</NavLink>
    <NavLink to="/blog" className="text-white me-3 text-decoration-none fw-medium">Blog</NavLink>
        </nav>
        {/* Right buttons */}
        <div className="d-flex align-items-center">
            <button className="btn btn-outline-light">Sign In</button>
        </div>
        </div>
        </header>
  );
};
